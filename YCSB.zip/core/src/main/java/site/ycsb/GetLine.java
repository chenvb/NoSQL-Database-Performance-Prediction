
package site.ycsb;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


/**
 * get a line.
 */
public class GetLine {
  private BufferedReader reader;

  public GetLine(String filePath) throws IOException {
    reader = new BufferedReader(new FileReader(filePath));
  }

  public synchronized String getNextLine() throws IOException {
    return reader.readLine();
  }
  
  public void close() throws IOException {
    if (reader != null) {
      reader.close();
    }
  }
}

